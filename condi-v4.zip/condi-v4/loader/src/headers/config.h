#pragma once

#define HTTP_SERVER "0.0.0.0"
#define HTTP_PORT 80

#define TFTP_SERVER "0.0.0.0"
